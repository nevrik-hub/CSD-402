/**
 * Program Name: RockPaperScissors.java
 * Author: Nicholas Zankl
 * Date: October 25, 2026
 * Course: CSD402
 * Description: This program simulates a classic Rock-Paper-Scissors game. 
 *              The computer randomly selects 1 (Rock), 2 (Paper), or 3 (Scissors). 
 *              The user is prompted for their choice, and the program 
 *              evaluates and displays the winner.
 */
 
import java.util.Random;
import java.util.Scanner;
 
public class RockPaperScissors {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Generate computer's choice: 1 for Rock, 2 for Paper, 3 for Scissors
        int computerChoice = random.nextInt(3) + 1;

        // Prompt the user for a choice
        System.out.println("========================================");
        System.out.println("       WELCOME TO ROCK-PAPER-SCISSORS     ");
        System.out.println("========================================");
        System.out.println("Please enter your choice:");
        System.out.println("  1. Rock");
        System.out.println("  2. Paper");
        System.out.println("  3. Scissors");
        System.out.print("Enter your selection (1-3): ");

        // Validate user input
        if (!scanner.hasNextInt()) {
            System.out.println("Error: Invalid input. Please enter a valid integer (1, 2, or 3).");
            scanner.close();
            return;
        }

        int userChoice = scanner.nextInt();

        // Check if the input is within the valid range (1-3)
        if (userChoice < 1 || userChoice > 3) {
            System.out.println("Error: Choice out of range. Please select 1, 2, or 3.");
            scanner.close();
            return;
        }

        // Convert numeric choices to readable text strings
        String computerChoiceStr = getChoiceName(computerChoice);
        String userChoiceStr = getChoiceName(userChoice);

        // Display selections clearly
        System.out.println("\n----------------------------------------");
        System.out.println("Computer's Selection : " + computerChoiceStr + " (" + computerChoice + ")");
        System.out.println("Your Selection       : " + userChoiceStr + " (" + userChoice + ")");
        System.out.println("----------------------------------------");

        // Determine and display the outcome
        String gameResult = determineWinner(userChoice, computerChoice);
        System.out.println("Result: " + gameResult);
        System.out.println("========================================");

        scanner.close();
    }

    /**
     * Helper method to map numeric codes to string names.
     * 
     * @param choice The integer choice (1, 2, or 3)
     * @return String representation of the choice
     */
    public static String getChoiceName(int choice) {
        switch (choice) {
            case 1:
                return "Rock";
            case 2:
                return "Paper";
            case 3:
                return "Scissors";
            default:
                return "Unknown";
        }
    }

    /**
     * Helper method to evaluate game rules and determine the winner.
     * 
     * @param user     The user's choice
     * @param computer The computer's choice
     * @return A string stating the outcome of the game
     */
    public static String determineWinner(int user, int computer) {
        if (user == computer) {
            return "It's a tie!";
        } else if ((user == 1 && computer == 3) || 
                   (user == 2 && computer == 1) || 
                   (user == 3 && computer == 2)) {
            return "Congratulations, you win!";
        } else {
            return "Computer wins! Better luck next time.";
        }
    }
}