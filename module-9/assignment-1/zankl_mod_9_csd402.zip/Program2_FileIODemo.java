/**
 * Title: File I/O Random Number Generator and Reader
 * Assignment: Module 9 Programming Assignment (Extended)
 * Author: Nicholas Zankl
 * Date: December 6, 2026
 * 
 * Purpose: Creates 'data.file', writes 10 newly generated random integers 
 * separated by spaces (overwriting previous run data for a clean display), 
 * closes the file, then reopens, reads, and displays the stored data.
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Scanner;

public class Program2_FileIODemo {
    public static void main(String[] args) {
        String fileName = "data.file";
        // Using SecureRandom with current time seeding to ensure unique, unpredictable numbers every execution
        SecureRandom random = new SecureRandom();

        // Step 1: Create 'data.file' if it does not exist, and write 10 random integers
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("File '" + fileName + "' created successfully.");
            } else {
                System.out.println("File '" + fileName + "' already exists. Overwriting with fresh random numbers...");
            }

            // Using append = false (default) so each execution gives a clean set of 10 numbers
            FileWriter writer = new FileWriter(file, false);
            
            // Generate 10 random integers separated by spaces
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                int randomNumber = random.nextInt(100) + 1; // Random number between 1 and 100
                sb.append(randomNumber).append(" ");
            }
            
            // Write data to file and close it
            writer.write(sb.toString().trim());
            writer.close();
            System.out.println("10 randomly generated numbers successfully written and file closed.");

        } catch (IOException e) {
            System.out.println("An I/O error occurred while writing: " + e.getMessage());
        }

        // Step 2: Reopen the file, read the data, and display it
        System.out.println("\n--- Reading Data from '" + fileName + "' ---");
        try {
            File file = new File(fileName);
            Scanner fileScanner = new Scanner(file);
            
            if (fileScanner.hasNextLine()) {
                String fileData = fileScanner.nextLine();
                System.out.println(fileData);
            }
            fileScanner.close();
            
        } catch (IOException e) {
            System.out.println("An I/O error occurred while reading: " + e.getMessage());
        }
    }
}