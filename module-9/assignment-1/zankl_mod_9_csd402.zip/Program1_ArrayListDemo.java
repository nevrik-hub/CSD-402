/**
 * Title: ArrayList Exception and Autoboxing Demo
 * Assignment: Module 9 Programming Assignment (Extended)
 * Author: Nicholas Zankl
 * Date: December 6, 2026
 * 
 * Purpose: Demonstrates an ArrayList of Strings, for-each loop printing, 
 * autoboxing/auto-unboxing with user input, and try/catch exception handling 
 * for out-of-bounds element retrieval.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Program1_ArrayListDemo {
    public static void main(String[] args) {
        // Create and populate an ArrayList with a minimum of 10 Strings
        ArrayList<String> items = new ArrayList<>();
        items.add("Apple");
        items.add("Banana");
        items.add("Cherry");
        items.add("Date");
        items.add("Elderberry");
        items.add("Fig");
        items.add("Grape");
        items.add("Honeydew");
        items.add("Kiwi");
        items.add("Lemon");

        // Use a for-each loop to print the ArrayList collection
        System.out.println("--- ArrayList Collection ---");
        for (String item : items) {
            System.out.println(item);
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter the index (0 to " + (items.size() - 1) + ") of the element you would like to see again: ");
        String userInput = scanner.nextLine();

        // Try/catch block for robust exception handling
        try {
            // Autoboxing and Auto-Unboxing demonstration with user's String input
            Integer indexObject = Integer.valueOf(userInput); // Parsing String input into an Integer object (Autoboxing)
            int index = indexObject;                         // Auto-unboxing the Integer object to a primitive int

            // Attempt to retrieve and print the element
            String selectedElement = items.get(index);
            System.out.println("Requested Element: " + selectedElement);
            
        } catch (IndexOutOfBoundsException e) {
            // Required output message when an invalid index is provided
            System.out.println("Exception has been thrown: Out of Bounds");
        } catch (NumberFormatException e) {
            // Handles cases where the user inputs non-numeric text
            System.out.println("Exception has been thrown: Out of Bounds (Invalid numeric format entered)");
        } finally {
            scanner.close();
        }
    }
}