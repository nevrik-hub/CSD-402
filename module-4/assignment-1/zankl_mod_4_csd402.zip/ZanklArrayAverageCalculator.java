/**
 * Title: Array Average Calculator
 * Assignment: Module 4.2: Programming Assignment
 * Author: Nicholas Zankl
 * Date: November 8, 2026
 * 
 * Purpose: This program demonstrates method overloading in Java by defining 
 * four separate methods to calculate the average of short, int, long, and double 
 * arrays. It includes a test driver that executes each method with arrays of 
 * different sizes and displays the results in a clear, formatted console output.
 */

import java.util.Arrays;

/**
 * The ArrayAverageCalculator class contains the overloaded average methods
 * and the main test program.
 */
public class ArrayAverageCalculator {

    /**
     * Calculates the average of an array of short values.
     * 
     * @param array the short array to process
     * @return the average value as a short
     */
    public static short average(short[] array) {
        if (array == null || array.length == 0) {
            return 0;
        }
        long sum = 0;
        for (short value : array) {
            sum += value;
        }
        return (short) (sum / array.length);
    }

    /**
     * Calculates the average of an array of int values.
     * 
     * @param array the int array to process
     * @return the average value as an int
     */
    public static int average(int[] array) {
        if (array == null || array.length == 0) {
            return 0;
        }
        long sum = 0;
        for (int value : array) {
            sum += value;
        }
        return (int) (sum / array.length);
    }

    /**
     * Calculates the average of an array of long values.
     * 
     * @param array the long array to process
     * @return the average value as a long
     */
    public static long average(long[] array) {
        if (array == null || array.length == 0) {
            return 0L;
        }
        long sum = 0;
        for (long value : array) {
            sum += value;
        }
        return sum / array.length;
    }

    /**
     * Calculates the average of an array of double values.
     * 
     * @param array the double array to process
     * @return the average value as a double
     */
    public static double average(double[] array) {
        if (array == null || array.length == 0) {
            return 0.0;
        }
        double sum = 0;
        for (double value : array) {
            sum += value;
        }
        return sum / array.length;
    }

    /**
     * Main test program that invokes each overloaded average method with 
     * arrays of different sizes and displays the results clearly.
     * 
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("          OVERLOADED ARRAY AVERAGE CALCULATOR     ");
        System.out.println("==================================================");

        // 1. Test short array (Size: 4)
        short[] shortArray = { 10, 25, 40, 55 };
        short shortAvg = average(shortArray);
        System.out.println("\n[1] Short Array (Size: " + shortArray.length + ")");
        System.out.println("    Elements : " + Arrays.toString(shortArray));
        System.out.println("    Average  : " + shortAvg);

        // 2. Test int array (Size: 5)
        int[] intArray = { 100, 200, 300, 400, 500 };
        int intAvg = average(intArray);
        System.out.println("\n[2] Integer Array (Size: " + intArray.length + ")");
        System.out.println("    Elements : " + Arrays.toString(intArray));
        System.out.println("    Average  : " + intAvg);

        // 3. Test long array (Size: 3)
        long[] longArray = { 1000L, 2500L, 4000L };
        long longAvg = average(longArray);
        System.out.println("\n[3] Long Array (Size: " + longArray.length + ")");
        System.out.println("    Elements : " + Arrays.toString(longArray));
        System.out.println("    Average  : " + longAvg);

        // 4. Test double array (Size: 6)
        double[] doubleArray = { 1.5, 2.5, 3.5, 4.5, 5.5, 6.5 };
        double doubleAvg = average(doubleArray);
        System.out.println("\n[4] Double Array (Size: " + doubleArray.length + ")");
        System.out.println("    Elements : " + Arrays.toString(doubleArray));
        System.out.println("    Average  : " + doubleAvg);

        System.out.println("\n==================================================");
        System.out.println("            TEST PROGRAM COMPLETED SUCCESSFULLY   ");
        System.out.println("==================================================");
    }
}