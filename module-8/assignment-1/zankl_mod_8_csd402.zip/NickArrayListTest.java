import java.util.ArrayList;
import java.util.Scanner;

/**
 * Title: NickArrayListTest
 * Assignment: Module 8 Programming Assignment (Extended)
 * Author: Nicholas Zankl
 * Date: November 29, 2026
 * 
 * Purpose: This program reads integers from user input until 0 is entered, 
 * stores them in an ArrayList (including the 0), and utilizes a static method 
 * to determine and return the largest value in the list. Additional test cases 
 * are also included to verify the robustness of the max method.
 */
 
public class NickArrayListTest {

    /**
     * Finds and returns the largest Integer value in the provided ArrayList.
     * 
     * @param list The ArrayList containing Integer values.
     * @return The maximum Integer in the list, or 0 if the list is empty or null.
     */
    public static Integer max(ArrayList list) {
        if (list == null || list.isEmpty()) {
            return 0;
        }
        
        Integer maxVal = (Integer) list.get(0);
        
        for (int i = 1; i < list.size(); i++) {
            Integer current = (Integer) list.get(i);
            if (current > maxVal) {
                maxVal = current;
            }
        }
        
        return maxVal;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> userList = new ArrayList<>();
        
        System.out.println("=== User Input Section ===");
        System.out.println("Enter integers one by one. Enter 0 to stop (0 will also be added to the list):");
        
        while (true) {
            System.out.print("Enter an integer: ");
            if (scanner.hasNextInt()) {
                int input = scanner.nextInt();
                userList.add(input);
                if (input == 0) {
                    break;
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // clear invalid token
            }
        }
        scanner.close();
        
        // Display user input list and the maximum value
        System.out.println("\nYour ArrayList: " + userList);
        Integer largestUserVal = max(userList);
        System.out.println("The largest value in your ArrayList is: " + largestUserVal);
        
        // --- Additional Code for Testing the max Method ---
        System.out.println("\n=== Automated Method Testing Section ===");
        
        // Test 1: Empty list
        ArrayList<Integer> emptyList = new ArrayList<>();
        System.out.println("Test 1 (Empty List): " + emptyList);
        System.out.println("Result (Expected: 0): " + max(emptyList));
        
        // Test 2: List with positive and negative numbers
        ArrayList<Integer> mixedList = new ArrayList<>();
        mixedList.add(-5);
        mixedList.add(42);
        mixedList.add(12);
        mixedList.add(0);
        System.out.println("\nTest 2 (Mixed List): " + mixedList);
        System.out.println("Result (Expected: 42): " + max(mixedList));
        
        // Test 3: List with all negative numbers
        ArrayList<Integer> negativeList = new ArrayList<>();
        negativeList.add(-10);
        negativeList.add(-3);
        negativeList.add(-25);
        System.out.println("\nTest 3 (All Negatives): " + negativeList);
        System.out.println("Result (Expected: -3): " + max(negativeList));
    }
}