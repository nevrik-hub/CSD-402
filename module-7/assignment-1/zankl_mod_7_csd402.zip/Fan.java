/**
 * Title: Fan Class Program v2
 * Assignment: Module 7 Programming Assignment (Extended)
 * Author: Nicholas Zankl
 * Date: November 22, 2026
 * 
 * Purpose: This program implements an encapsulated Fan class with constant definitions, 
 * private attributes, constructors, validation getters/setters, the 'this' reference, 
 * and a customized toString() method.
 */

public class Fan {
    // Four constants for fan speed
    public static final int STOPPED = 0;
    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    // Private fields (encapsulated for data hiding)
    private int speed;
    private boolean on;
    private double radius;
    private String color;

    /**
     * No-argument constructor that sets all fields to their default values 
     * using the 'this' reference.
     */
    public Fan() {
        this.speed = STOPPED;
        this.on = false;
        this.radius = 6.0;
        this.color = "white";
    }

    /**
     * Parameterized constructor that initializes all fields with specified values,
     * utilizing setters and the 'this' reference.
     */
    public Fan(int speed, boolean on, double radius, String color) {
        this.setSpeed(speed);
        this.setOn(on);
        this.setRadius(radius);
        this.setColor(color);
    }

    // --- Getter and Setter Methods with Validation and 'this' reference ---

    public int getSpeed() {
        return this.speed;
    }

    public void setSpeed(int speed) {
        if (speed < STOPPED || speed > FAST) {
            throw new IllegalArgumentException("Invalid speed: " + speed + ". Speed must be between " + STOPPED + " and " + FAST + ".");
        }
        this.speed = speed;
    }

    public boolean isOn() {
        return this.on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public double getRadius() {
        return this.radius;
    }

    public void setRadius(double radius) {
        if (radius <= 0) {
            throw new IllegalArgumentException("Invalid radius: " + radius + ". Radius must be greater than 0.");
        }
        this.radius = radius;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        if (color == null || color.trim().isEmpty()) {
            throw new IllegalArgumentException("Color cannot be null or empty.");
        }
        this.color = color.trim();
    }

    /**
     * Returns a string description of the fan's current state using 'this'.
     */
    @Override
    public String toString() {
        String speedStr;
        switch (this.speed) {
            case SLOW:
                speedStr = "SLOW";
                break;
            case MEDIUM:
                speedStr = "MEDIUM";
                break;
            case FAST:
                speedStr = "FAST";
                break;
            default:
                speedStr = "STOPPED";
                break;
        }

        if (this.on) {
            return "Fan State: ON | Speed: " + speedStr + " | Color: " + this.color + " | Radius: " + this.radius;
        } else {
            return "Fan State: OFF | Color: " + this.color + " | Radius: " + this.radius;
        }
    }

    /**
     * Original Module 6 test main method.
     */
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("            FAN CLASS TEST PROGRAM                ");
        System.out.println("==================================================\n");

        Fan defaultFan = new Fan();
        System.out.println("Default Fan Initial State:");
        System.out.println(defaultFan.toString());

        defaultFan.setSpeed(FAST);
        defaultFan.setOn(true);
        defaultFan.setRadius(8.0);
        defaultFan.setColor("Blue");

        System.out.println("\nDefault Fan Updated State:");
        System.out.println(defaultFan.toString());
    }
}