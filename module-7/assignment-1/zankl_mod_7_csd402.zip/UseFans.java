/**
 * Title: UseFans Class Program
 * Assignment: Module 6 Programming Assignment Extension (UseFans)
 * Author: Nicholas Zankl
 * Date: November 22, 2026
 * 
 * Purpose: Demonstrates the creation of a collection of Fan instances and 
 * provides dedicated display methods for single and multiple fans without 
 * relying on the toString() method.
 */
 
import java.util.ArrayList;
import java.util.List;

public class UseFans {

    /**
     * Displays a single instance of a Fan by extracting its properties 
     * via getters, without calling toString().
     * 
     * @param fan the Fan instance to display
     */
    public static void displayFan(Fan fan) {
        if (fan == null) {
            System.out.println("Error: Fan instance is null.");
            return;
        }

        String speedStr;
        switch (fan.getSpeed()) {
            case Fan.SLOW:
                speedStr = "SLOW";
                break;
            case Fan.MEDIUM:
                speedStr = "MEDIUM";
                break;
            case Fan.FAST:
                speedStr = "FAST";
                break;
            default:
                speedStr = "STOPPED";
                break;
        }

        // Display properties manually using getters
        if (fan.isOn()) {
            System.out.println("[Display Method] State: ON | Speed: " + speedStr + 
                               " | Color: " + fan.getColor() + " | Radius: " + fan.getRadius());
        } else {
            System.out.println("[Display Method] State: OFF | Speed: " + speedStr + 
                               " | Color: " + fan.getColor() + " | Radius: " + fan.getRadius());
        }
    }

    /**
     * Displays a collection of Fan instances by iterating through them 
     * and leveraging the single-fan display method, without calling toString().
     * 
     * @param fans the collection of Fan instances
     */
    public static void displayFans(List<Fan> fans) {
        if (fans == null || fans.isEmpty()) {
            System.out.println("The fan collection is empty.");
            return;
        }

        int count = 1;
        for (Fan fan : fans) {
            System.out.print("Fan #" + count + " -> ");
            displayFan(fan);
            count++;
        }
    }

    /**
     * Test code creating a collection of Fans and displaying their functionality.
     */
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("            USE FANS TEST PROGRAM                 ");
        System.out.println("==================================================\n");

        // 1. Create a collection (ArrayList) of Fan instances
        List<Fan> fanInventory = new ArrayList<>();

        // Populate collection with various default and parameterized fans
        fanInventory.add(new Fan()); // Default fan
        fanInventory.add(new Fan(Fan.FAST, true, 8.5, "Red"));
        fanInventory.add(new Fan(Fan.MEDIUM, true, 12.0, "Silver"));
        fanInventory.add(new Fan(Fan.SLOW, false, 7.0, "Black"));

        // 2. Display the entire collection using the collection display method (No toString)
        System.out.println("--- Displaying Full Collection of Fans (Without toString) ---");
        displayFans(fanInventory);

        // 3. Demonstrate individual fan functionality and modification
        System.out.println("\n--- Demonstrating Individual Fan Updates & Functionality ---");
        Fan targetFan = fanInventory.get(1); // Getting the Red Fast Fan
        
        System.out.println("Before changes (Fan #2):");
        displayFan(targetFan);

        // Modify properties using setters
        System.out.println("\nModifying Fan #2: Turning OFF and changing speed to STOPPED...");
        targetFan.setOn(false);
        targetFan.setSpeed(Fan.STOPPED);
        targetFan.setColor("Crimson");

        System.out.println("After changes (Fan #2):");
        displayFan(targetFan);

        System.out.println("\n==================================================");
        System.out.println("           TEST EXECUTION COMPLETE                ");
        System.out.println("==================================================");
    }
}