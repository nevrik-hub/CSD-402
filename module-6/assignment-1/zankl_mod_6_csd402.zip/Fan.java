/**
 * Title: Fan Class Program
 * Assignment: Module 6.2: Programming Assignment
 * Author: Nicholas Zankl
 * Date: November 15, 2026
 * 
 * Purpose: This program implements a Fan class containing constant definitions, 
 * private attributes, constructors, getters, setters with validation, and a 
 * customized toString() method. It includes comprehensive test code demonstrating 
 * both default and parameterized instances, method functionality, and defensive 
 * exception handling for invalid inputs.
 */

public class Fan {
    // Four constants for fan speed
    public static final int STOPPED = 0;
    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    // Private fields (encapsulated for data hiding)
    private int speed;
    private boolean on;
    private double radius;
    private String color;

    /**
     * No-argument constructor that sets all fields to their default values:
     * - speed: STOPPED (0)
     * - on: false (off)
     * - radius: 6.0
     * - color: "white"
     */
    public Fan() {
        this.speed = STOPPED;
        this.on = false;
        this.radius = 6.0;
        this.color = "white";
    }

    /**
     * Parameterized constructor that initializes all fields with specified values,
     * utilizing setters to ensure input validation rules are enforced upon creation.
     * 
     * @param speed  the speed of the fan
     * @param on     whether the fan is on or off
     * @param radius the radius of the fan
     * @param color  the color of the fan
     */
    public Fan(int speed, boolean on, double radius, String color) {
        setSpeed(speed);
        setOn(on);
        setRadius(radius);
        setColor(color);
    }

    // --- Getter and Setter Methods with Validation ---

    public int getSpeed() {
        return speed;
    }

    /**
     * Sets the speed of the fan with validation. 
     * Uses defensive programming to check that the input falls within the 
     * defined constant range [0, 3], maintaining object state integrity.
     * 
     * @param speed the speed value to set
     * @throws IllegalArgumentException if the speed is outside the range [0, 3]
     */
    public void setSpeed(int speed) {
        if (speed < STOPPED || speed > FAST) {
            // Throw an exception to reject illegal state transitions
            throw new IllegalArgumentException("Invalid speed: " + speed + ". Speed must be between " + STOPPED + " and " + FAST + ".");
        }
        this.speed = speed;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public double getRadius() {
        return radius;
    }

    /**
     * Sets the radius of the fan with validation.
     * Ensures physical plausibility by checking that the radius is strictly positive.
     * 
     * @param radius the radius value to set
     * @throws IllegalArgumentException if the radius is less than or equal to 0
     */
    public void setRadius(double radius) {
        if (radius <= 0) {
            // Throw an exception to prevent physically impossible dimensions
            throw new IllegalArgumentException("Invalid radius: " + radius + ". Radius must be greater than 0.");
        }
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    /**
     * Sets the color of the fan with validation.
     * Ensures that color strings are neither null nor empty whitespace.
     * 
     * @param color the color to set
     * @throws IllegalArgumentException if the color is null or empty
     */
    public void setColor(String color) {
        if (color == null || color.trim().isEmpty()) {
            throw new IllegalArgumentException("Color cannot be null or empty.");
        }
        this.color = color.trim();
    }

    /**
     * Returns a string description of the fan's current state.
     * 
     * @return a formatted string representing the fan properties
     */
    @Override
    public String toString() {
        String speedStr;
        switch (speed) {
            case SLOW:
                speedStr = "SLOW";
                break;
            case MEDIUM:
                speedStr = "MEDIUM";
                break;
            case FAST:
                speedStr = "FAST";
                break;
            default:
                speedStr = "STOPPED";
                break;
        }

        if (on) {
            return "Fan State: ON | Speed: " + speedStr + " | Color: " + color + " | Radius: " + radius;
        } else {
            return "Fan State: OFF | Color: " + color + " | Radius: " + radius;
        }
    }

    /**
     * Test code to demonstrate the functionality of the Fan class, 
     * including successful operations and exception-handling blocks for invalid inputs.
     */
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("            FAN CLASS TEST PROGRAM                ");
        System.out.println("==================================================\n");

        // 1. Create an instance using the default constructor
        Fan defaultFan = new Fan();
        System.out.println("--- Testing Default Constructor & Methods ---");
        System.out.println("Default Fan Initial State:");
        System.out.println(defaultFan.toString());

        // Modify the default fan using valid setter inputs
        System.out.println("\nModifying default fan properties using setters...");
        defaultFan.setSpeed(FAST);
        defaultFan.setOn(true);
        defaultFan.setRadius(8.0);
        defaultFan.setColor("Blue");

        System.out.println("Default Fan Updated State:");
        System.out.println(defaultFan.toString());

        // Test individual getters
        System.out.println("\nRetrieving properties via Getters:");
        System.out.println("- Speed Code: " + defaultFan.getSpeed());
        System.out.println("- Power Status: " + defaultFan.isOn());
        System.out.println("- Radius: " + defaultFan.getRadius());
        System.out.println("- Color: " + defaultFan.getColor());

        System.out.println("\n--------------------------------------------------\n");

        // 2. Demonstrate Exception Handling and Input Validation
        System.out.println("--- Testing Setter Input Validation & Exception Handling ---");
        
        // Try-catch block to gracefully catch and handle illegal speed arguments
        try {
            System.out.println("Attempting to set an invalid speed (5)...");
            defaultFan.setSpeed(5); // This will trigger an IllegalArgumentException
        } catch (IllegalArgumentException e) {
            System.out.println("Caught Expected Exception: " + e.getMessage());
        }

        // Try-catch block to gracefully catch and handle illegal radius arguments
        try {
            System.out.println("\nAttempting to set an invalid negative radius (-3.0)...");
            defaultFan.setRadius(-3.0); // This will trigger an IllegalArgumentException
        } catch (IllegalArgumentException e) {
            System.out.println("Caught Expected Exception: " + e.getMessage());
        }

        System.out.println("\n--------------------------------------------------\n");

        // 3. Create an instance using the parameterized constructor
        System.out.println("--- Testing Parameterized Constructor ---");
        Fan customFan = new Fan(MEDIUM, true, 10.5, "Black");
        System.out.println("Custom Fan Initial State (Created via arguments):");
        System.out.println(customFan.toString());

        // Modify custom fan state
        System.out.println("\nTurning off custom fan and changing speed to SLOW...");
        customFan.setOn(false);
        customFan.setSpeed(SLOW);
        System.out.println("Custom Fan Final State:");
        System.out.println(customFan.toString());

        System.out.println("\n==================================================");
        System.out.println("           TEST EXECUTION COMPLETE                ");
        System.out.println("==================================================");
    }
}