/**
 * Title: Powers of Two Pyramid Pattern
 * Assignment: Module 3.2: Programming Assignment
 * Author: Nicholas Zankl
 * Date: November 1, 2026
 * 
 * Purpose: Uses nested for loops to output a symmetrical pyramid of powers of 2 
 *          with aligned spacing and an '@' symbol at the end of each line.
 */
public class PowersPattern {
    public static void main(String[] args) {
        int totalRows = 7; // Total number of rows in the pattern

        // Outer loop for each row
        for (int i = 0; i < totalRows; i++) {
            
            // 1. Print leading spaces for pyramid alignment
            for (int s = 0; s < (totalRows - 1 - i) * 3; s++) {
                System.out.print(" ");
            }

            // 2. Inner loop 1: Print ascending powers of 2 (from 2^0 up to 2^i)
            int currentVal = 1;
            for (int j = 0; j <= i; j++) {
                System.out.print(currentVal + " ");
                currentVal *= 2;
            }

            // 3. Inner loop 2: Print descending powers of 2 (from 2^(i-1) down to 2^0)
            currentVal /= 4; // Adjust back to the peak's preceding power
            for (int j = 0; j < i; j++) {
                System.out.print(currentVal);
                if (j < i - 1) {
                    System.out.print(" ");
                }
                currentVal /= 2;
            }

            // 4. Print the '@' symbol at the end of each line
            System.out.println(" @");
        }
    }
}