/**
 * Title: 2D Array Min/Max Location Finder
 * Assignment: Module 5.2: Programming Assignment
 * Author: Nicholas Zankl
 * Date: November 15, 2026
 * 
 * Purpose: This program defines and tests methods to locate the row and column indices 
 *          of the largest and smallest elements within 2D integer and double arrays.
 */

public class ArrayLocationFinder {

    /**
     * Locates the largest element in a 2D double array.
     * 
     * @param arrayParam A 2D double array to search.
     * @return A 1D integer array containing two elements: [row, column] of the largest value.
     */
    public static int [] locateLargest (double [] [] arrayParam) {
        if (arrayParam == null || arrayParam.length == 0 || arrayParam[0].length == 0) {
            return new int[] {-1, -1};
        }
        
        int maxRow = 0;
        int maxCol = 0;
        double maxVal = arrayParam[0][0];
        
        for (int i = 0; i < arrayParam.length; i++) {
            for (int j = 0; j < arrayParam[i].length; j++) {
                if (arrayParam[i][j] > maxVal) {
                    maxVal = arrayParam[i][j];
                    maxRow = i;
                    maxCol = j;
                }
            }
        }
        
        return new int[] {maxRow, maxCol};
    }

    /**
     * Locates the largest element in a 2D int array.
     * 
     * @param arrayParam A 2D int array to search.
     * @return A 1D integer array containing two elements: [row, column] of the largest value.
     */
    public static int [] locateLargest (int [] [] arrayParam) {
        if (arrayParam == null || arrayParam.length == 0 || arrayParam[0].length == 0) {
            return new int[] {-1, -1};
        }
        
        int maxRow = 0;
        int maxCol = 0;
        int maxVal = arrayParam[0][0];
        
        for (int i = 0; i < arrayParam.length; i++) {
            for (int j = 0; j < arrayParam[i].length; j++) {
                if (arrayParam[i][j] > maxVal) {
                    maxVal = arrayParam[i][j];
                    maxRow = i;
                    maxCol = j;
                }
            }
        }
        
        return new int[] {maxRow, maxCol};
    }

    /**
     * Locates the smallest element in a 2D double array.
     * 
     * @param arrayParam A 2D double array to search.
     * @return A 1D integer array containing two elements: [row, column] of the smallest value.
     */
    public static int [] locateSmallest (double [] [] arrayParam) {
        if (arrayParam == null || arrayParam.length == 0 || arrayParam[0].length == 0) {
            return new int[] {-1, -1};
        }
        
        int minRow = 0;
        int minCol = 0;
        double minVal = arrayParam[0][0];
        
        for (int i = 0; i < arrayParam.length; i++) {
            for (int j = 0; j < arrayParam[i].length; j++) {
                if (arrayParam[i][j] < minVal) {
                    minVal = arrayParam[i][j];
                    minRow = i;
                    minCol = j;
                }
            }
        }
        
        return new int[] {minRow, minCol};
    }

    /**
     * Locates the smallest element in a 2D int array.
     * 
     * @param arrayParam A 2D int array to search.
     * @return A 1D integer array containing two elements: [row, column] of the smallest value.
     */
    public static int [] locateSmallest (int [] [] arrayParam) {
        if (arrayParam == null || arrayParam.length == 0 || arrayParam[0].length == 0) {
            return new int[] {-1, -1};
        }
        
        int minRow = 0;
        int minCol = 0;
        int minVal = arrayParam[0][0];
        
        for (int i = 0; i < arrayParam.length; i++) {
            for (int j = 0; j < arrayParam[i].length; j++) {
                if (arrayParam[i][j] < minVal) {
                    minVal = arrayParam[i][j];
                    minRow = i;
                    minCol = j;
                }
            }
        }
        
        return new int[] {minRow, minCol};
    }

    /**
     * Main method to test the implemented methods.
     */
    public static void main(String[] args) {
        // Test Int Array
        int[][] intArray = {
            {12, 45, 23},
            {99, 4, 67},
            {34, 88, 12}
        };
        
        int[] intLargest = locateLargest(intArray);
        int[] intSmallest = locateSmallest(intArray);
        
        System.out.println("Int Array Largest Location: [" + intLargest[0] + ", " + intLargest[1] + "]");
        System.out.println("Int Array Smallest Location: [" + intSmallest[0] + ", " + intSmallest[1] + "]");

        // Test Double Array
        double[][] doubleArray = {
            {1.5, 2.3, 0.9},
            {5.6, 5.7, 3.2},
            {4.1, 0.1, 2.8}
        };
        
        int[] doubleLargest = locateLargest(doubleArray);
        int[] doubleSmallest = locateSmallest(doubleArray);
        
        System.out.println("Double Array Largest Location: [" + doubleLargest[0] + ", " + doubleLargest[1] + "]");
        System.out.println("Double Array Smallest Location: [" + doubleSmallest[0] + ", " + doubleSmallest[1] + "]");
    }
}